using UnityEngine;
using UnityEngine.Splines;

namespace Weapons.Attacks
{
    public class ProjectileAttack : Attack
    {
        private Spline _path;
        private float _speed;

        private float _distanceTraveled;
        private float _totalPathLength;
        
        private Vector3 _startPosition;
        private Quaternion _rotation;

        public void Initialize(Spline path, float speed, float damage, string allyTag)
        {
            Initialize(damage, allyTag);
            
            _path = path;
            _path.Copy(path);
            _speed = speed;
            
            _totalPathLength = path.CalculateLength(transform.worldToLocalMatrix);
            
            _startPosition = transform.position;
            _rotation = transform.rotation;
        }
        
        private void FixedUpdate()
        {
            _distanceTraveled += _speed * Time.fixedDeltaTime;
            
            float t = Mathf.Clamp01(_distanceTraveled / _totalPathLength);
            
            Vector3 pos = _startPosition + _rotation * _path.EvaluatePosition(t);
            transform.position = pos;
            
            if (Mathf.Approximately(t, 1f))
                Destroy(gameObject);
        }

        protected override void OnTriggerEnter2D(Collider2D otherCollider)
        {
            base.OnTriggerEnter2D(otherCollider);

            if (otherCollider.CompareTag(_allyTag))
                return;
            
            Destroy(gameObject);
        }
    }
}